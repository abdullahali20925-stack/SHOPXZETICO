import https from 'https';

function searchDuckDuckGo(query) {
  return new Promise((resolve, reject) => {
    https.get(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const matches = data.match(/<img[^>]+src="([^">]+)"/g);
        if (matches) {
          const urls = matches.map(m => m.match(/src="([^">]+)"/)[1]).filter(u => u.startsWith('http'));
          resolve(urls[0]);
        } else {
          resolve(null);
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  const queries = [
    "gaming earphones with mic red and black",
    "samsung AKG type-c earphones with box",
    "Piva S6 esports earphones",
    "HyperX cloud earbuds 2 in case",
    "Piva S6 esports falcon earphones"
  ];
  for (let q of queries) {
    const url = await searchDuckDuckGo(q);
    console.log(q, " => ", url);
  }
}
run();
