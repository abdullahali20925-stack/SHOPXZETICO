import { ShoppingCart } from 'lucide-react';
import { Product } from '../types';
import { motion } from 'motion/react';
import { useCart } from '../contexts/CartContext';

interface Props {
  key?: string | number;
  product: Product;
}

export function ProductCard({ product }: Props) {
  const { addToCart } = useCart();

  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="group bg-[#151515] border border-white/5 p-4 rounded-xl flex flex-col gap-3 h-full transition-all hover:border-gaming-blue"
    >
      <div className="h-48 bg-gradient-to-br from-[#1a1a1a] to-[#0D0D0D] rounded-lg relative overflow-hidden flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-gaming-blue/5 group-hover:bg-gaming-blue/10 transition-colors z-0" />
        <img 
          src={product.imageUrl} 
          alt={product.name}
          className="w-full h-full object-cover rounded-md opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all z-10"
        />
        {product.isNew && (
          <div className="absolute top-2 left-2 bg-gaming-purple text-white text-[10px] uppercase font-bold px-2 py-0.5 rounded shadow-lg z-20">
            NEW
          </div>
        )}
      </div>

      <div className="flex-1 flex flex-col">
        <div>
          <p className="text-gaming-purple text-[10px] font-bold uppercase tracking-widest mb-1">
            {product.category}
          </p>
          <h3 className="font-bold text-sm tracking-tight text-white line-clamp-2">
            {product.name}
          </h3>
        </div>

        <div className="mt-auto pt-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gaming-blue font-mono">
              PKR {product.price.toLocaleString()}
            </span>
          </div>
          <button 
            onClick={() => addToCart(product)}
            className="w-full mt-3 py-2 bg-white/5 hover:bg-white/10 text-[10px] text-white uppercase font-bold tracking-widest rounded transition-colors flex items-center justify-center gap-2"
          >
            <ShoppingCart className="w-3 h-3" />
            Quick Buy
          </button>
        </div>
      </div>
    </motion.div>
  );
}
