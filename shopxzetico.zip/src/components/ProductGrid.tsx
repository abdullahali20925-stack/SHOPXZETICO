import { ProductCard } from './ProductCard';
import { Product } from '../types';

interface Props {
  id: string;
  title: string;
  subtitle: string;
  products: Product[];
}

export function ProductGrid({ id, title, subtitle, products }: Props) {
  return (
    <section id={id} className="py-24 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div className="space-y-1">
            <span className="text-gaming-blue text-[10px] font-bold uppercase tracking-[0.3em]">{subtitle}</span>
            <h2 className="text-4xl md:text-5xl font-black italic tracking-tighter uppercase">{title}</h2>
          </div>
          <button className="text-gaming-purple font-black text-xs uppercase tracking-widest hover:text-gaming-blue transition-colors flex items-center gap-2">
            View All Collection
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
