import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[600px] h-[600px] bg-gaming-purple rounded-full blur-[150px] opacity-20 pointer-events-none" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[500px] h-[500px] bg-gaming-blue rounded-full blur-[120px] opacity-20 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-5xl mx-auto flex flex-col items-center"
        >
          <span className="text-gaming-blue text-sm font-bold uppercase tracking-[0.3em] mb-4">
            Premium Gaming Gear
          </span>
          
          <h1 className="text-6xl md:text-8xl lg:text-[7rem] font-black leading-[0.9] tracking-tighter italic mb-8">
            LEVEL UP YOUR <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-gaming-blue to-gaming-purple">
              EXPERIENCE.
            </span>
          </h1>
          
          <p className="text-zinc-400 text-sm md:text-base max-w-2xl mx-auto mb-10 leading-relaxed font-medium">
            Elevate your gameplay with premium mobile gaming cooling fans, splitters, and elite audio gear. ShopXzetio is the definitive tactical hub for competitive mobile gamers since 2023.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="w-full sm:w-auto px-10 py-4 rounded-sm bg-gaming-blue hover:bg-gaming-blue/90 text-black font-black uppercase italic tracking-wider transition-all shadow-[0_0_25px_rgba(0,191,255,0.4)] flex items-center justify-center gap-2">
              Shop Gaming Gear
            </button>
            <button className="w-full sm:w-auto px-10 py-4 rounded-sm bg-transparent border-2 border-gaming-purple hover:bg-gaming-purple/10 text-white font-black uppercase italic tracking-wider transition-all">
              View Top Rated
            </button>
          </div>

          <div className="mt-16 flex justify-center gap-12 md:gap-20 border-t border-white/10 pt-10">
            <div className="flex flex-col items-center">
              <span className="text-2xl md:text-3xl font-bold font-mono">15K+</span>
              <span className="text-[10px] uppercase text-gray-500 tracking-widest mt-1">Active Gamers</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-2xl md:text-3xl font-bold font-mono">4.9/5</span>
              <span className="text-[10px] uppercase text-gray-500 tracking-widest mt-1">Community Score</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-2xl md:text-3xl font-bold font-mono">24/7</span>
              <span className="text-[10px] uppercase text-gray-500 tracking-widest mt-1">Expert Support</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
