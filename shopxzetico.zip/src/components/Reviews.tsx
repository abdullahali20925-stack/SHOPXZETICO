import { REVIEWS } from '../data';
import { Star, Quote } from 'lucide-react';
import { motion } from 'motion/react';

export function Reviews() {
  return (
    <section className="py-24 bg-[#111] relative z-10 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-1">
          <span className="text-gaming-purple text-[10px] font-bold uppercase tracking-[0.3em]">Community</span>
          <h2 className="text-4xl md:text-5xl font-black italic tracking-tighter uppercase">Player Testimonials</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {REVIEWS.map((review, index) => (
            <motion.div 
              key={review.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-[#151515] rounded-xl p-8 border border-white/5 relative group hover:border-gaming-purple transition-colors"
            >
              <Quote className="absolute top-6 right-6 w-10 h-10 text-gaming-purple/5 group-hover:text-gaming-purple/10 transition-colors" />
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-5 h-5 ${i < review.rating ? 'fill-gaming-purple text-gaming-purple' : 'text-zinc-800'}`} 
                  />
                ))}
              </div>
              
              <p className="text-zinc-400 text-sm mb-8 leading-relaxed italic">"{review.content}"</p>
              
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#1a1a1a] to-[#0D0D0D] border border-white/5 flex items-center justify-center font-bold text-sm text-gaming-purple">
                  {review.author.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-sm tracking-tight text-white">{review.author}</h4>
                  <p className="text-[10px] text-gaming-blue uppercase tracking-widest font-mono">{review.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
