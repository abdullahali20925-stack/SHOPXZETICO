import { Instagram, Phone, Mail, Facebook } from 'lucide-react';
import shopXzetioLogo from '../assets/images/shopxzetio_logo_1779385871754.png';

export function Footer() {
  return (
    <footer className="w-full bg-[#111] border-t border-white/5 pt-16 pb-8 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-1">
            <a href="#" className="inline-block mb-4">
              <img src={shopXzetioLogo} alt="ShopXzetio Logo" className="h-12 w-auto object-contain" />
            </a>
            <p className="text-gray-400 text-xs mb-6 font-medium">
              Level Up Your Gaming Experience. The ultimate destination for gamers worldwide.
            </p>
            <div className="flex gap-6 text-[10px] text-gray-500 uppercase font-bold tracking-widest">
              <a href="https://instagram.com/shopxzetio_" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors flex items-center gap-1">
                <Instagram className="w-4 h-4" /> @shopxzetio_
              </a>
              <a href="https://facebook.com/ShopXzetio" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors flex items-center gap-1">
                <Facebook className="w-4 h-4" /> ShopXzetio
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-white mb-6 uppercase tracking-[0.2em] text-[10px] text-gaming-blue">Store</h4>
            <ul className="space-y-4 text-xs font-semibold uppercase tracking-widest">
              <li><a href="#handsfrees" className="text-gray-500 hover:text-white transition-colors">Handsfrees</a></li>
              <li><a href="#splitters-tc" className="text-gray-500 hover:text-white transition-colors">Splitters</a></li>
              <li><a href="#cooling" className="text-gray-500 hover:text-white transition-colors">Cooling Fans</a></li>
              <li><a href="#headphones" className="text-gray-500 hover:text-white transition-colors">Headphones</a></li>
              <li><a href="#sleeves" className="text-gray-500 hover:text-white transition-colors">Sleeves</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-6 uppercase tracking-[0.2em] text-[10px] text-gaming-purple">Support</h4>
            <ul className="space-y-4 text-xs font-semibold uppercase tracking-widest">
              <li><a href="#" className="text-gray-500 hover:text-white transition-colors">Shipping Info</a></li>
              <li><a href="#" className="text-gray-500 hover:text-white transition-colors">Returns</a></li>
              <li><a href="#" className="text-gray-500 hover:text-white transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-6 uppercase tracking-[0.2em] text-[10px]">Contact Us</h4>
            <ul className="space-y-4 text-xs font-mono">
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-gaming-blue shrink-0" />
                <span className="text-gray-400">WhatsApp: 03348590229</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-gaming-blue shrink-0" />
                <a href="mailto:support@shopxzetio.com" className="text-gaming-blue hover:text-white transition-colors">
                  support@shopxzetio.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[10px] text-gray-600 uppercase font-bold tracking-widest">
            &copy; {new Date().getFullYear()} SHOPXZETIO. DESIGNED FOR THE NEXT GENERATION.
          </p>
          <div className="flex gap-6 text-[10px] text-gray-500 uppercase font-bold tracking-widest">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
