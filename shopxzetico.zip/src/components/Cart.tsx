import { X, Minus, Plus, ShoppingBag, ArrowLeft, Send } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';

export function Cart() {
  const { items, isCartOpen, setIsCartOpen, removeFromCart, updateQuantity, cartTotal } = useCart();
  const [isCheckout, setIsCheckout] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  const submitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    let message = "New Order from ShopXzetio!\n\n";
    items.forEach(item => {
      message += `${item.quantity}x ${item.name} - PKR ${(item.price * item.quantity).toLocaleString()}\n`;
    });
    message += `\nTotal: PKR ${cartTotal.toLocaleString()}\n\n`;
    message += `Customer Details:\nName: ${name}\nPhone: ${phone}\nAddress: ${address}`;

    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/923348590229?text=${encodedMessage}`, '_blank');
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsCartOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-gaming-bg border-l border-white/10 z-50 flex flex-col shadow-2xl"
          >
            <div className="flex items-center justify-between p-6 border-b border-white/5">
              <h2 className="text-xl font-bold uppercase tracking-wider flex items-center gap-2">
                {isCheckout ? (
                  <>
                    <button onClick={() => setIsCheckout(false)} className="mr-2 text-zinc-400 hover:text-white transition-colors">
                      <ArrowLeft className="w-5 h-5" />
                    </button>
                    Checkout Details
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-5 h-5 text-gaming-blue" />
                    Your Cart
                  </>
                )}
              </h2>
              <button
                onClick={() => setIsCartOpen(false)}
                className="p-2 text-zinc-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!isCheckout ? (
              <>
                <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
                  {items.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-zinc-500 gap-4">
                      <ShoppingBag className="w-12 h-12 opacity-20" />
                      <p className="uppercase tracking-widest text-sm font-semibold">Your cart is empty</p>
                    </div>
                  ) : (
                    items.map((item) => (
                      <div key={item.id} className="flex gap-4 items-center bg-white/5 p-4 rounded-lg">
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-20 h-20 object-cover rounded-md bg-[#1a1a1a]"
                        />
                        <div className="flex-1">
                          <h3 className="font-bold text-sm line-clamp-2">{item.name}</h3>
                          <div className="text-gaming-purple font-mono text-sm mt-1">
                            PKR {item.price.toLocaleString()}
                          </div>
                          <div className="flex items-center gap-3 mt-3">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="w-6 h-6 flex items-center justify-center bg-white/10 rounded hover:bg-white/20 transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="w-6 h-6 flex items-center justify-center bg-white/10 rounded hover:bg-white/20 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-2 text-zinc-500 hover:text-red-400 transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {items.length > 0 && (
                  <div className="p-6 border-t border-white/5 bg-black/20">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-zinc-400 font-medium">Subtotal</span>
                      <span className="text-xl font-bold font-mono">PKR {cartTotal.toLocaleString()}</span>
                    </div>
                    <button 
                      onClick={() => setIsCheckout(true)}
                      className="w-full bg-gaming-blue hover:bg-blue-600 text-white font-bold uppercase tracking-wider py-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                    >
                      Proceed to Checkout
                    </button>
                  </div>
                )}
              </>
            ) : (
              <form onSubmit={submitOrder} className="flex-1 flex flex-col min-h-0">
                <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-1">Full Name</label>
                    <input 
                      type="text" 
                      required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-gaming-blue focus:ring-1 focus:ring-gaming-blue transition-all"
                      placeholder="e.g. Ali Hassan"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-1">Phone Number (WhatsApp)</label>
                    <input 
                      type="tel" 
                      required
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-gaming-blue focus:ring-1 focus:ring-gaming-blue transition-all"
                      placeholder="03xx-xxxxxxx"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-1">Shipping Address</label>
                    <textarea 
                      required
                      rows={3}
                      value={address}
                      onChange={e => setAddress(e.target.value)}
                      className="w-full bg-black/50 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-gaming-blue focus:ring-1 focus:ring-gaming-blue transition-all max-h-32 min-h-[80px]"
                      placeholder="Enter your full address"
                    />
                  </div>

                  <div className="p-4 bg-white/5 rounded-lg mt-4 border border-white/5">
                    <p className="text-zinc-400 text-xs mb-2 uppercase tracking-wide font-bold">Order Summary</p>
                    <div className="space-y-1 mb-3">
                      {items.map(item => (
                        <div key={item.id} className="flex justify-between text-sm">
                          <span className="text-zinc-300">{item.quantity}x {item.name}</span>
                          <span className="text-zinc-500 font-mono">PKR {(item.price * item.quantity).toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between items-center pt-3 border-t border-white/5">
                      <span className="font-bold">Total</span>
                      <span className="font-mono text-gaming-purple font-bold">PKR {cartTotal.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 border-t border-white/5 bg-black/20">
                  <button type="submit" className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white font-bold uppercase tracking-wider py-4 rounded-lg transition-colors flex items-center justify-center gap-2">
                    <Send className="w-5 h-5" />
                    Send via WhatsApp
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
