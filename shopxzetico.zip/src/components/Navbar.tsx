import { ShoppingCart, Menu, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { useCart } from '../contexts/CartContext';
import shopXzetioLogo from '../assets/images/shopxzetio_logo_1779385871754.png';

export function Navbar() {
  const { cartCount, setIsCartOpen } = useCart();

  return (
    <nav className="fixed top-0 w-full z-50 bg-gaming-bg/95 backdrop-blur-md border-b border-gaming-purple/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center gap-2">
            <motion.a 
              href="#" 
              className="flex items-center"
              whileHover={{ scale: 1.05 }}
            >
              <img src={shopXzetioLogo} alt="ShopXzetio Logo" className="h-12 w-auto object-contain" />
            </motion.a>
          </div>

          <div className="hidden md:flex gap-8 text-sm font-semibold uppercase tracking-widest">
            <a href="#handsfrees" className="text-zinc-300 hover:text-gaming-blue transition-colors">Handsfrees</a>
            <a href="#splitters-tc" className="text-zinc-300 hover:text-gaming-blue transition-colors">Splitters</a>
            <a href="#cooling" className="text-zinc-300 hover:text-gaming-blue transition-colors">Cooling Fans</a>
            <a href="#headphones" className="text-zinc-300 hover:text-gaming-blue transition-colors">Headphones</a>
            <a href="#sleeves" className="text-zinc-300 hover:text-gaming-blue transition-colors">Sleeves</a>
          </div>

          <div className="flex items-center gap-6">
            <button className="text-zinc-300 hover:text-white transition-colors hidden sm:block">
              <Search className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative text-gaming-blue hover:text-white transition-colors group"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-gaming-purple text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  {cartCount}
                </span>
              )}
            </button>
            <button className="md:hidden text-zinc-300">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
