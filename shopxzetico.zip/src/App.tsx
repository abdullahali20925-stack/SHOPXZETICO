import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductGrid } from './components/ProductGrid';
import { Reviews } from './components/Reviews';
import { Footer } from './components/Footer';
import { Cart } from './components/Cart';
import { HANDSFREES, TYPE_C_SPLITTERS, LIGHTNING_SPLITTERS, COOLING_FANS, HEADPHONES, SLEEVES } from './data';
import { CartProvider } from './contexts/CartContext';

export default function App() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-gaming-bg text-white selection:bg-gaming-purple selection:text-white">
        <Navbar />
        <Cart />
        
        <main>
        <Hero />
        
        <ProductGrid 
          id="handsfrees"
          title="GAMING HANDSFREES" 
          subtitle="Top audio quality for esports."
          products={HANDSFREES} 
        />
        
        <ProductGrid 
          id="splitters-tc"
          title="TYPE-C SPLITTERS" 
          subtitle="Seamless charging & audio."
          products={TYPE_C_SPLITTERS} 
        />

        <ProductGrid 
          id="splitters-lt"
          title="LIGHTNING SPLITTERS" 
          subtitle="Zero latency adapters."
          products={LIGHTNING_SPLITTERS} 
        />

        <ProductGrid 
          id="cooling"
          title="COOLING FANS" 
          subtitle="Stay icy under pressure."
          products={COOLING_FANS} 
        />

        <ProductGrid 
          id="headphones"
          title="GAMING HEADPHONES" 
          subtitle="Immersive soundscapes."
          products={HEADPHONES} 
        />

        <ProductGrid 
          id="sleeves"
          title="ESPORTS SLEEVES" 
          subtitle="Smooth glides, precision aim."
          products={SLEEVES} 
        />

        <Reviews />
      </main>

      <Footer />
      </div>
    </CartProvider>
  );
}
