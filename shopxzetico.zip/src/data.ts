import { Product, Review } from './types';

import gGamingImg from './assets/images/g_gaming_handsfree_1779283059074.png';
import akgOriginalImg from './assets/images/akg_original_1779283084793.png';
import pivaS6ProImg from './assets/images/piva_s6_pro_1779283105933.png';
import hyperxImg from './assets/images/hyperx_cloud_earbuds_1779283127614.png';
import pivaFalconImg from './assets/images/piva_s6_falcon_1779283149050.png';

import plextoneGs1Img from './assets/images/plextone_gs1_1779382573379.png';
import plextoneGs1Mark3Img from './assets/images/plextone_gs1_mark3_1779382593759.png';
import pivaGs3ProImg from './assets/images/piva_gs3_pro_1779382612888.png';
import pivaDs7Img from './assets/images/piva_ds7_1779382634915.png';
import pivaG71Img from './assets/images/piva_g71_1779382657436.png';

import joyroomLightningImg from './assets/images/joyroom_lightning_1779382932298.png';
import plextoneGs1LightningImg from './assets/images/plextone_gs1_lightning_1779382957457.png';
import pivaG2GenuineImg from './assets/images/piva_g2_genuine_1779382978702.png';
import pivaG2CopyImg from './assets/images/piva_g2_copy_1779383006604.png';
import belkinLightningImg from './assets/images/belkin_lightning_1779383025612.png';
import pivaSleevesImg from './assets/images/piva_sleeves_1779383834816.png';

import hyperxCloud2Img from './assets/images/hyperx_cloud_2_1779384066683.png';
import hyperxCloudAlphaImg from './assets/images/hyperx_cloud_alpha_1779384093359.png';
import hyperxCloudAlphaSImg from './assets/images/hyperx_cloud_alpha_s_1779384117930.png';
import hyperxCloudStinger2Img from './assets/images/hyperx_cloud_stinger_2_1779384139527.png';
import hyperxCloudCoreImg from './assets/images/hyperx_cloud_core_1779384163408.png';
import logitechGProXImg from './assets/images/logitech_g_pro_x_1779384191159.png';
import logitechG335Img from './assets/images/logitech_g335_1779384210678.png';

import pivaB2Img from './assets/images/piva_b2_mobile_1779385896947.png';
import pivaB3Img from './assets/images/piva_b3_mobile_1779385917006.png';
import pivaX30Img from './assets/images/piva_x30_mobile_1779385936652.png';
import pivaB2MaxImg from './assets/images/piva_b2_max_mobile_1779385956994.png';
import memoCx08Img from './assets/images/memo_cx08_1779385628143.png';
import memoCx16Img from './assets/images/memo_cx16_1779385647171.png';
import memoCx15Img from './assets/images/memo_cx15_1779385672536.png';

// Helper for fast image mock based on type
const imgs = {
  handsfree: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=800',
  splitter: 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=800',
  fan: 'https://images.unsplash.com/photo-1616763355548-1b606f439f86?auto=format&fit=crop&q=80&w=800',
  headphone: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?auto=format&fit=crop&q=80&w=800',
  sleeve: 'https://images.unsplash.com/photo-1502239608882-93b729c6af43?auto=format&fit=crop&q=80&w=800'
};

export const HANDSFREES: Product[] = [
  { id: 'hf1', name: 'G gaming Handsfree', category: 'Handsfree', price: 2250, imageUrl: gGamingImg, isNew: true },
  { id: 'hf2', name: 'Akg Original', category: 'Handsfree', price: 2500, imageUrl: akgOriginalImg },
  { id: 'hf3', name: 'Piva S6 Pro', category: 'Handsfree', price: 9500, imageUrl: pivaS6ProImg, isNew: true },
  { id: 'hf4', name: 'HyperXcloud Earbuds 2', category: 'Handsfree', price: 8500, imageUrl: hyperxImg },
  { id: 'hf5', name: 'Piva S6 Esports Falcon', category: 'Handsfree', price: 4500, imageUrl: pivaFalconImg },
];

export const TYPE_C_SPLITTERS: Product[] = [
  { id: 'tc1', name: 'Plextone GS1', category: 'Type C Splitter', price: 3000, imageUrl: plextoneGs1Img },
  { id: 'tc2', name: 'Plextone GS1 Markiii', category: 'Type C Splitter', price: 5000, imageUrl: plextoneGs1Mark3Img },
  { id: 'tc3', name: 'Piva GS3 Pro', category: 'Type C Splitter', price: 6500, imageUrl: pivaGs3ProImg, isNew: true },
  { id: 'tc4', name: 'Piva DS7', category: 'Type C Splitter', price: 8200, imageUrl: pivaDs7Img },
  { id: 'tc5', name: 'Piva G71', category: 'Type C Splitter', price: 10800, imageUrl: pivaG71Img },
];

export const LIGHTNING_SPLITTERS: Product[] = [
  { id: 'ls1', name: 'Joyroom', category: 'Lightning Splitter', price: 3100, imageUrl: joyroomLightningImg },
  { id: 'ls2', name: 'Plextone Gs1', category: 'Lightning Splitter', price: 4000, imageUrl: plextoneGs1LightningImg },
  { id: 'ls3', name: 'Piva G2 Genuine', category: 'Lightning Splitter', price: 6500, imageUrl: pivaG2GenuineImg, isNew: true },
  { id: 'ls4', name: 'Piva G2 1st high copy', category: 'Lightning Splitter', price: 5000, imageUrl: pivaG2CopyImg },
  { id: 'ls5', name: 'Belkin Original', category: 'Lightning Splitter', price: 7500, imageUrl: belkinLightningImg },
];

export const COOLING_FANS: Product[] = [
  { id: 'cf1', name: 'Piva B2', category: 'Cooling Fan', price: 3850, imageUrl: pivaB2Img },
  { id: 'cf2', name: 'Piva B3', category: 'Cooling Fan', price: 4350, imageUrl: pivaB3Img },
  { id: 'cf3', name: 'Piva X30', category: 'Cooling Fan', price: 4000, imageUrl: pivaX30Img },
  { id: 'cf4', name: 'Piva B2 Max', category: 'Cooling Fan', price: 8500, imageUrl: pivaB2MaxImg, isNew: true },
  { id: 'cf5', name: 'Memo Cx08', category: 'Cooling Fan', price: 2850, imageUrl: memoCx08Img },
  { id: 'cf6', name: 'Memo cx16', category: 'Cooling Fan', price: 2850, imageUrl: memoCx16Img },
  { id: 'cf7', name: 'Memo Cx15', category: 'Cooling Fan', price: 2850, imageUrl: memoCx15Img },
];

export const HEADPHONES: Product[] = [
  { id: 'hp1', name: 'HyperXcloud 2 (Used)', category: 'Headphone', price: 10500, imageUrl: hyperxCloud2Img },
  { id: 'hp2', name: 'HyperXcloud Alpha', category: 'Headphone', price: 10000, imageUrl: hyperxCloudAlphaImg },
  { id: 'hp3', name: 'HyperXcloud Alpha S', category: 'Headphone', price: 14500, imageUrl: hyperxCloudAlphaSImg, isNew: true },
  { id: 'hp4', name: 'HyperXcloud Stinger 2', category: 'Headphone', price: 6500, imageUrl: hyperxCloudStinger2Img },
  { id: 'hp5', name: 'HyperXcloud Core', category: 'Headphone', price: 9500, imageUrl: hyperxCloudCoreImg },
  { id: 'hp6', name: 'Logetich G Pro X', category: 'Headphone', price: 31000, imageUrl: logitechGProXImg, isNew: true },
  { id: 'hp7', name: 'Logetich C335', category: 'Headphone', price: 10000, imageUrl: logitechG335Img },
];

export const SLEEVES: Product[] = [
  { id: 'sl1', name: 'Piva Sleeves pack of 3 pairs', category: 'Esports Sleeve', price: 1400, imageUrl: pivaSleevesImg },
];

export const REVIEWS: Review[] = [
  {
    id: 'r1',
    author: 'Ali "Snipeh" Hassan',
    role: 'PUBG Mobile Pro',
    content: 'The Piva S6 Pro handsfree is amazing for long sessions. My comms are completely clear now, and the Plextone GS1 splitter lets me charge while playing!',
    rating: 5,
  },
  {
    id: 'r2',
    author: 'Ayesha Khan',
    role: 'Mobile Gamer',
    content: 'I got the G gaming Handsfree and a pair of Piva sleeves. The sound quality is great for the price, and the sleeves really help with aim consistency.',
    rating: 5,
  },
  {
    id: 'r3',
    author: 'Bilal Ahmed',
    role: 'Competitive Player',
    content: 'Ordered the HyperXcloud Alpha S and it was delivered quickly. Best esports headset I have used so far. Highly recommend shopping here for original gear!',
    rating: 5,
  }
];
