export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  imageUrl: string;
  isNew?: boolean;
  rating?: number;
}

export interface Review {
  id: string;
  author: string;
  role: string;
  content: string;
  rating: number;
}
