const https = require('https');

function searchDuckDuckGo(query) {
  return new Promise((resolve, reject) => {
    https.get(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
        headers: { 'User-Agent': 'Mozilla/5.0' }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const matches = data.match(/<img[^>]+src="([^">]+)"/g);
        if (matches) {
          const urls = matches.map(m => m.match(/src="([^">]+)"/)[1]).filter(u => u.startsWith('http'));
          resolve(urls[0]);
        } else {
          resolve(null);
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  const queries = [
    "earphones",
  ];
  for (let q of queries) {
    const url = await searchDuckDuckGo(q);
    console.log(url);
  }
}
run();
